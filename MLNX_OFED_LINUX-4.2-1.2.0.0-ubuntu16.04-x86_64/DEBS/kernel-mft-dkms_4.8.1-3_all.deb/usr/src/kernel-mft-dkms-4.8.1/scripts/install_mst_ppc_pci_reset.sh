#!/bin/bash
set -e

kernel_version="`uname -r`"
path_to_build="`pwd`"
path_to_build="$path_to_build/../build"
cd $path_to_build

mkdir -p /etc/mft/mlxfwreset/$kernel_version
/bin/cp -f ./mst_ppc_pci_reset.ko /etc/mft/mlxfwreset/$kernel_version/

cd -

