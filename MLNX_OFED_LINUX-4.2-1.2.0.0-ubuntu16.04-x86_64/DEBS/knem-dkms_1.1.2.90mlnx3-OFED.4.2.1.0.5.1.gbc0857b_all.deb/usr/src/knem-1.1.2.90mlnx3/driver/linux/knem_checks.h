#ifndef __knem_checks_h__
#define __knem_checks_h__ 1

/*
 * This file has been first generated on Wed Nov 29 09:12:43 IST 2017
 * Ran with BUILD="/lib/modules/4.4.0-22-generic/build" HDR="/lib/modules/4.4.0-22-generic/build" RELEASE="4.4.0-22-generic"
 * It checked kernel headers in /lib/modules/4.4.0-22-generic/build/include/
 */

#define KNEM_HAVE_VMALLOC_USER 1
#define KNEM_HAVE_REMAP_VMALLOC_RANGE 1
#define KNEM_HAVE_GET_USER_PAGES_FAST 1
#define KNEM_HAVE_CPUMASK_PR_ARGS 1
#define KNEM_HAVE_CPUMASK_OF_NODE 1
#define KNEM_HAVE_CPUMASK_COMPLEMENT 1
#define KNEM_HAVE_SET_CPUS_ALLOWED_PTR 1
#define KNEM_HAVE_RCU_IDR 1
#define KNEM_HAVE_IDR_PRELOAD 1
#define KNEM_HAVE_IDA 1
#define KNEM_HAVE_DMA_ENGINE_API 1
#define KNEM_HAVE_IS_DMA_COPY_ALIGNED 1
#define KNEM_HAVE_DMA_ASYNC_ISSUE_PENDING 1
#define KNEM_HAVE_DMA_ASYNC_IS_TX_COMPLETE 1
#define KNEM_HAVE_DMA_COMPLETE 1
#define KNEM_HAVE_DMAENGINE_GET_UNMAP_DATA 1
#define KNEM_HAVE_CURRENT_UID 1
#define KNEM_HAVE_CRED_KUID 1
#define KNEM_HAVE_PRINTK_ONCE 1

#endif /* __knem_checks_h__ */
